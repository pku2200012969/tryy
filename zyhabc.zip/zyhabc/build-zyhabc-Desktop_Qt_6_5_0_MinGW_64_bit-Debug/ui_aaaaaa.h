/********************************************************************************
** Form generated from reading UI file 'aaaaaa.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AAAAAA_H
#define UI_AAAAAA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_aaaaaa
{
public:
    QPushButton *pushButton;

    void setupUi(QDialog *aaaaaa)
    {
        if (aaaaaa->objectName().isEmpty())
            aaaaaa->setObjectName("aaaaaa");
        aaaaaa->resize(800, 600);
        pushButton = new QPushButton(aaaaaa);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(260, 210, 91, 41));

        retranslateUi(aaaaaa);

        QMetaObject::connectSlotsByName(aaaaaa);
    } // setupUi

    void retranslateUi(QDialog *aaaaaa)
    {
        aaaaaa->setWindowTitle(QCoreApplication::translate("aaaaaa", "aaaaaa", nullptr));
        pushButton->setText(QCoreApplication::translate("aaaaaa", "close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class aaaaaa: public Ui_aaaaaa {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AAAAAA_H
