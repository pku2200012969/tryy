#include "aaaaaa.h"
#include "ui_aaaaaa.h"

aaaaaa::aaaaaa(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::aaaaaa)
{
    ui->setupUi(this);
}

aaaaaa::~aaaaaa()
{
    delete ui;
}


void aaaaaa::on_pushButton_clicked()
{
    this->close();
}

